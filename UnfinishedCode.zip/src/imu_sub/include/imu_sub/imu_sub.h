// IMU Sub Class Header File

#ifndef IMU_SUB_H
#define IMU_SUB_H

#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "imu_sub/imu.h"

class ImuFilt
{

public:
    ImuFilt(); // constructor

private:
    IMU imu;

    double acc[3];
    double gyro[3];

    double q[4];
    double dT;

    ros::NodeHandle n;
    ros::Subscriber sub;
    ros::Publisher pub;

    void qCall(const sensor_msgs::Imu::ConstPtr &msg);
    void publishQ();
};

#endif
